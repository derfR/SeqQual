#!/usr/bin/env perl


print "SeqQual process of separating phd.ball file.\n\n";
