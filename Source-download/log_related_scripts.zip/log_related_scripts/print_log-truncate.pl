#!/usr/bin/env perl


$trunc=shift;
exit if $trunc==0;
print "Truncate the alignments.\n";
print "Truncate_parameter=$trunc\n\n";
