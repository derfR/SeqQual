#!/usr/bin/env perl


print "Write SNP alignment files.\n\n";

