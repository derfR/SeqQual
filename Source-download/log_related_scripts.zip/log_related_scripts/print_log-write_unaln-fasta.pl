#!/usr/bin/env perl


print "Write unaligned fasta files.\n\n";
