#!/usr/bin/env perl


print "SeqQual process with fasta_aln routine.\n\n";
