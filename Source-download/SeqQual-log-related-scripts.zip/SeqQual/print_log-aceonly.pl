#!/usr/bin/env perl


print "SeqQual process with ace_only routine.\n\n";
