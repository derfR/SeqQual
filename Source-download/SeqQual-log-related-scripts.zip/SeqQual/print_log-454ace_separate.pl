#!/usr/bin/env perl


print "SeqQual process of separating ace file.\n\n";
