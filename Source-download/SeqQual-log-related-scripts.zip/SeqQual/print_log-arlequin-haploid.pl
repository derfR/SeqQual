#!/usr/bin/env perl


$arg1=$ARGV[0];
$arg2=$ARGV[1];
$arg3=$ARGV[2];
$arg4=$ARGV[3];
$arg5=$ARGV[4];
$arg6=$ARGV[5];
$arg7=$ARGV[6];
$arg8=$ARGV[7];
$arg9=$ARGV[8];
$arg10=$ARGV[9];
$arg11=$ARGV[10];
$arg12=$ARGV[11];
$arg13=$ARGV[12];
$arg14=$ARGV[13];
$arg15=$ARGV[14];
$arg16=$ARGV[15];
$arg17=$ARGV[16];
$arg18=$ARGV[17];
$arg19=$ARGV[18];
$arg20=$ARGV[19];
print "Create arlequin input files.\n";
print scalar(@ARGV), " groups.\n";
print "Group names: ","@ARGV","\n\n";

