#!/usr/bin/env perl


print "SeqQual process with haploid_ace routine.\n\n";
