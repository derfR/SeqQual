#!/usr/bin/env perl


print "Remove columns with only "?" and "-" in alignment files.\n\n";
