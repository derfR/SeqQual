#!/usr/bin/env perl


$phredscore=shift;
print "Write unaligned fasta files.\n";
print "Phred_score=$phredscore\n\n";
