#!/usr/bin/env perl


print "Split large phd.ball file(s).\n\n";
