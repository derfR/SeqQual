#!/usr/bin/env perl


$replace=shift;
print "Replace isolated nucleotides in alignment files.\n";
print "Replace_parameter=$replace\n\n";

