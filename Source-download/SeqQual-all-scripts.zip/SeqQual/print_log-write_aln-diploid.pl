#!/usr/bin/env perl


$phredscore=shift;
$genotypescore=shift;
print "Write fasta alignment files.\n";
print "Phred_score=$phredscore\n";
print "Genotype_score=$genotypescore\n\n";
