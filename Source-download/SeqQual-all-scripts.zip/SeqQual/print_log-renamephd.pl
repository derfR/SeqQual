#!/usr/bin/env perl


print "Rename phd files.\n\n";
