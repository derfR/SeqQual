#!/usr/bin/env perl


print "SeqQual process with ace.\n\n";
