#!/usr/bin/env perl


print "Write haplotype phase unknown alignment files.\n";

