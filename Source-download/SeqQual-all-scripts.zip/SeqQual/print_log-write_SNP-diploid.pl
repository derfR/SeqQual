#!/usr/bin/env perl


$phredscore=shift;
$genotypescore=shift;
print "Write SNP alignment files.\n";
print "Phred_score=$phredscore\n";
print "Genotype_score=$genotypescore\n\n";
