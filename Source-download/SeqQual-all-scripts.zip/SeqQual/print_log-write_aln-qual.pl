#!/usr/bin/env perl


$phredscore=shift;
print "Write fasta alignment files.\n";
print "Phred_score=$phredscore\n\n";
