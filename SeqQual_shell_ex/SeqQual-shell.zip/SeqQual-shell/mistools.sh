#!/bin/sh
# Examples of use for various SeqQual scripts 

# Use within the folder where fasta *.aln are located
echo Merging F and R fragments - same ID
perl ~/SeqQual-additions/merge_multinput_F_R.pl

perl ~/SeqQual-additions/merge_multinput_IUPAC.pl pop1  # will merge any sequences/reads starting which names starts with "pop1"

perl ~/SeqQual-additions/merge_multinput.pl 10  # will merge any sequences/reads starting with 10 similar characters

# Picks only sequences/reads starting with pop1 and pop2 in batch in different fasta *.aln (before making consensus for example)
perl ~/SeqQual/pick-seq.pl pop1 pop2 *.aln  

## For making consensus, use command line within folder with files

# if needed, remove the first sequence if it is already a consensus sequence or the sequence of 
# a reference species, use within folder where fasta *.aln are
perl ~/SeqQual/remove_first.pl

perl ~/SeqQual/make_consensus_IUPAC_2N.pl

perl ~/SeqQual/make_consensus_maxallele_N.pl

perl ~/SeqQual/make_consensus_maxallele_2N.pl

# Gets first sequence (assumed to be te consensus) in a set of fasta *.aln, to use within the files' folder
perl ~/SeqQual/get_first.pl








